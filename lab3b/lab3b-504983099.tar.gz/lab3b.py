import sys
import csv


def dothings(the_reader):
    block_map = dict()
    '''record of blocks get from free block list, 0 if free'''
    inode_map = dict()
    '''same thing for inode, 0 if free'''
    the_inodes = list()
    the_dirents = list()
    the_indirects = list()
    hugelist = list()
    blockmap = dict()
    for row in the_reader:
        hugelist.append(row)
    '''scan it for the bitmaps and general information, not doing only one 
    scan because the order of the csv might be messed up'''
    for row in hugelist:
        the_head = row[0]
        if the_head == "SUPERBLOCK":
            block_size = int(row[3])
            inode_size = int(row[4])
            first_nonreserved_inode = int(row[7])

        if the_head == "GROUP":
            block_num = int(row[2])
            inode_num = int(row[3])
            freeblock_num = int(row[4])
            freeinode_num = int(row[5])
            first_inode_block = int(row[8])

        if the_head == "BFREE":
            '''if not (row[1]<0 or row[1]>block_num): i didn't find the sentence to output 
            in this kind of error, so i would just ignore it'''
            block_map[int(row[1])] = 0

        if the_head == "IFREE":
            '''if not (row[1] < 0 or row[1] > inode_num):'''
            inode_map[int(row[1])] = 0

        if the_head == "INDIRECT":
            the_indirects.append(row)

        if the_head == "DIRENT":
            the_dirents.append(row)

    '''scan it for the second time to buffer the inodes and do some checking'''

    for row in hugelist:
        the_head = row[0]
        if the_head == "INODE":
            the_inode = int(row[1])
            if the_inode in inode_map:
                print("ALLOCATED INODE " + row[1] + " ON FREELIST")
                inode_map[the_inode] = -1
            else:
                inode_map[the_inode] = 1
            the_inodes.append(row)



    '''check for empty nonallocated inodes who are not in the inode free list'''
    for i in range(first_nonreserved_inode, inode_num + 1):
        if i not in inode_map:
            print("UNALLOCATED INODE " + str(i) + " NOT ON FREELIST")

    for node in the_inodes:
        if node[2] == "s" and int(node[10]) <= 60:
            continue
        for j in range(12, 27):
            block = int(node[j])
            if block == 0:
                continue
            t = "BLOCK "
            offset = 0
            if j == 24:
                t = "INDIRECT BLOCK "
                offset = 12
            if j == 25:
                t = "DOUBLE INDIRECT BLOCK "
                offset = 12 + 256
            if j == 26:
                t = "TRIPLE INDIRECT BLOCK "
                offset = 12 + 256 + 256 * 256
            if block in block_map:
                if block_map[block] == 0:
                    print("ALLOCATED BLOCK " + str(block) + " ON FREELIST")
                else:
                    print("DUPLICATE " + block_map[block][1] + str(block) + " IN INODE " + \
                    block_map[block][0] + " AT OFFSET " + str(block_map[block][2]))
                    block_map[block] = (node[1], t, offset, 1)
            else:
                if block < 0 or block > block_num:
                    print("INVALID " + t + str(block) + " IN INODE " + node[1] + " AT OFFSET " + str(offset))
                elif block < first_inode_block:
                    print("RESERVED " + t + str(block) + " IN INODE " + node[1] + " AT OFFSET " + str(offset))
                else:
                    block_map[block] = (node[1], t, offset)

    for indirect in the_indirects:
        iinode = indirect[1]
        '''string'''
        level = int(indirect[2])
        block = int(indirect[5])
        t = "BLOCK "
        offset = int(indirect[3])
        if level == 1:
            t = "INDIRECT BLOCK "
        if level == 2:
            t = "DOUBLE BLOCK "
        if level == 3:
            t = "TRIPLE BLOCK "

        if block in block_map:
            if block_map[block] == 0:
                print("ALLOCATED BLOCK " + str(block) + " ON FREELIST")
            else:
                print("DUPLICATE " + block_map[block][1] + str(block) + " IN INODE " + \
                      block_map[block][0] + " AT OFFSET " + str(block_map[block][2]))
                block_map[block] = (iinode, t, offset, 1)
        else:
            if block < 0 or block > block_num:
                print("INVALID " + t + str(block) + " IN INODE " + iinode + " AT OFFSET " + str(offset))
            elif block < first_inode_block:
                print("RESERVED " + t + str(block) + " IN INODE " + iinode + " AT OFFSET " + str(offset))
            else:
                block_map[block] = (iinode, t, offset)

    '''print the leftover duplicates'''
    for p in block_map:
        if block_map[p] != 0:
                if len(block_map[p]) == 4:
                    print("DUPLICATE " + block_map[p][1] + str(p) + " IN INODE " + block_map[p][0] + " AT OFFSET " + \
                    str(block_map[p][2]))

    first_after_inode_block = first_inode_block + int(inode_size * inode_num / block_size)
    for i in range(first_after_inode_block, block_num):
        if i not in block_map:
            print("UNREFERENCED BLOCK " + str(i))

    sondad = dict()
    inode_countdir=dict()
    for direct in the_dirents:
        if direct[6] != "'.'" and direct[6] != "'..'":
            sondad[direct[3]] = direct[1]


    for direct in the_dirents:
        if direct[6] == "'.'":
            if direct[1] != direct[3]:
                print("DIRECTORY INODE " + direct[1] + " NAME '.'" + " LINK TO INODE " + direct[3] + " SHOULD BE "
                      + direct[1])
        if direct[6] == "'..'":
            if direct[1] in sondad:
                if direct[3] != sondad[direct[1]]:
                    print("DIRECTORY INODE " + direct[1] + " NAME '..'" + " LINK TO INODE " + direct[3] + " SHOULD BE "
                          + sondad[direct[1]])
            elif direct[1] != direct[3]:
                print("DIRECTORY INODE " + direct[1] + " NAME '..'" + " LINK TO INODE " + direct[3] + " SHOULD BE "
                      + direct[1])

    '''check for invalid inode in directories'''
    for direct in the_dirents:
        if int(direct[3]) < 1 or int(direct[3]) > inode_num:
            print("DIRECTORY INODE " + direct[1] + " NAME " + direct[6] + " INVALID INODE " + direct[3])

        if int(direct[3]) in inode_map and inode_map[int(direct[3])] == 0:
            print("DIRECTORY INODE " + direct[1] + " NAME " + direct[6] + " UNALLOCATED INODE " + direct[3])

    '''check for link count and if inode is allocaed'''
    for direct in the_dirents:
        if direct[3] not in inode_countdir:
            inode_countdir[direct[3]] = 1
        else:
            inode_countdir[direct[3]] += 1

    for inode in the_inodes:
        if inode[1] in inode_countdir:
            if int(inode[6]) != inode_countdir[inode[1]]:
                print("INODE " + inode[1] + " HAS " + str(inode_countdir[inode[1]]) + " LINKS BUT LINKCOUNT IS " +
                      inode[6])
        else:
            print("INODE " + inode[1] + " HAS 0 LINKS BUT LINKCOUNT IS " + inode[6])

def main():

    if len(sys.argv) != 2:
        sys.stderr.write("the number of argumetns is wrong\n")
        exit(1)

    try:
        with open(sys.argv[1]) as csvfile:
            the_reader = csv.reader(csvfile, delimiter=',')
            dothings(the_reader)


    except IOError:
        sys.stderr.write("cannot read the csv file \n")
        exit(1)




if __name__ == "__main__":
    main()