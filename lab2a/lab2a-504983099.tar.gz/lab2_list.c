/* NAME: Yining Wang */
/* EMAIL: wangyining@g.ucla.edu */
/* ID: 504983099 */

#include "SortedList.h"

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#include <getopt.h>
#include <signal.h>
#include <errno.h>
#include <string.h>
int opt_yield=0;
int threadnum=1;
int iternum=1;

int spin_lock=0;
char syncflag=0; //0 when no flag at all

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
SortedList_t list = {&list, &list, NULL};
SortedListElement_t *randomstuff;

//yieldflags



/*
void SortedList_insert(SortedList_t *list, SortedListElement_t *element);
int SortedList_delete( SortedListElement_t *element);
SortedListElement_t *SortedList_lookup(SortedList_t *list, const char *key);
int SortedList_length(SortedList_t *list);
*/

char *randomkey() {
  int length = rand() % 10+1;
  char *key = malloc(sizeof(char) * (length + 1));
  for (int i = 0; i < length; i++)
    key[i] = rand() % 100 + 60;
  key[length] = '\0';
  return key;
}

void* threadfunc(void* val) {
	//insert shit in
	
	int start= iternum * *((int *) val);
	int end= start+iternum;
	for(int i=start; i<end; i++){
		if(syncflag==0){
			SortedList_insert(&list, &randomstuff[i]); 
		}
		if(syncflag=='m'){
			pthread_mutex_lock(&lock);
            SortedList_insert(&list, &randomstuff[i]);
            pthread_mutex_unlock(&lock);
		}
		if(syncflag=='s'){
			while (__sync_lock_test_and_set(&spin_lock, 1))
                continue;  
            SortedList_insert(&list, &randomstuff[i]);
            __sync_lock_release(&spin_lock);
		}			
	}
	
	//get the length
	int ret = 0;
    if(syncflag==0)  
		ret = SortedList_length(&list); 
    else if(syncflag=='m'){
        pthread_mutex_lock(&lock);
        ret = SortedList_length(&list);
        pthread_mutex_unlock(&lock);
	}
    else if(syncflag=='s'){
        while (__sync_lock_test_and_set(&spin_lock, 1))
            continue;
        ret = SortedList_length(&list);
        __sync_lock_release(&spin_lock);
    }
    if (ret < 0) {  //  Check for list corruption
        fprintf(stderr, "from the length we see that the list is corrupted\n");
        exit(2);
    }
	
	
	//lookup and delete
	for(int i=start; i<end; i++){
		if(syncflag==0) {
			SortedListElement_t *element = SortedList_lookup(&list, randomstuff[i].key);    
			if (SortedList_delete(element)){
				fprintf(stderr,"corruption detected from lookup and deleete \n");
				exit(2);
			}
		}
		else if (syncflag=='m'){
			pthread_mutex_lock(&lock);
            SortedListElement_t *element = SortedList_lookup(&list, randomstuff[i].key);    
			if (SortedList_delete(element)){
				fprintf(stderr,"corruption detected from lookup and deleete \n");
				exit(2);
			}
            pthread_mutex_unlock(&lock);
		}
		
		else if (syncflag=='s'){
			while (__sync_lock_test_and_set(&spin_lock, 1))
				continue;
			SortedListElement_t *element = SortedList_lookup(&list, randomstuff[i].key);    
			if (SortedList_delete(element)){
				fprintf(stderr,"corruption detected from lookup and deleete \n");
				exit(2);
			}
			__sync_lock_release(&spin_lock);
		}
	}
	return NULL;
}



struct option options[] = {
  {"threads", 1, 0, 1}, //THREADS
  {"iterations", 1, 0, 2}, //ITERATIONS
  {"yield", 1, 0, 3}, //YIELD
  {"sync", 1, 0, 4},//SYNC
  {0, 0, 0, 0}
};

void signal_handler_fun(int num) {
   fprintf(stderr,"%d caught\n",num);
   exit(2);
}

int main(int argc, char **argv) {
	
	
	int yi=0;
	int yd=0;
	int yl=0;
	
	char *type = malloc(sizeof(char) * 20);
	char * final= malloc(sizeof(char) * 5);
	
	int opt;
	while((opt=getopt_long(argc, argv, "", options, NULL))!=-1){
	
		
		switch(opt){
			case 1: //threads
			//printf("%s \n", optarg);
			threadnum=atoi(optarg);
			if(threadnum<0){
				fprintf(stderr, "thread number is not possible\n");
				exit(1);
			}
			break;
			
			case 2: //iterations
			//printf("%s \n", optarg);
			iternum=atoi(optarg);
			if(iternum<0){
				fprintf(stderr, "the iteration number is not positive \n");
				exit(1);
			}
			break;
			
			case 3: //yield
			//printf("%s \n", optarg);	
			//printf("found it \n ");
			if(strlen(optarg)>3){
				fprintf(stderr, "too many operands for yield, wrong\n");
				exit(1);
			}
			for(long unsigned int i=0;i<strlen(optarg);i++){
				char temp=optarg[i];
				if (temp!='i'&& temp!='d'&&temp!='l'){
					fprintf(stderr, "the operand for yield is wrong\n");
					exit(1);
				}
				else if(temp=='i') {
					yi=1;
					//printf("ia");
					opt_yield |= INSERT_YIELD;
				}
				else if (temp=='d'){ 
					yd=1;
					opt_yield |= DELETE_YIELD;
				}
				else if (temp=='l') {
					yl=1;
					opt_yield |= LOOKUP_YIELD;
				}
			}
		
			break;
			
			case 4: //sync
			//printf("%s \n", optarg);
			syncflag=optarg[0];
			if(strlen(optarg)>1) {
				fprintf(stderr, "argument after sync is too many \n");
				exit(1);
			}
			if(syncflag!='m' && syncflag!='s'){
				fprintf(stderr, "argument after sync is not supported \n");
				exit(1);
			}
			break;
			
			default:
			fprintf(stderr, "argument not recognized \n");
			exit(1);
		
		}
	}
	
	
	//get the yield flags into the final string 
	 //{none, i,d,l,id,il,dl,idl}
	
	if(yi==0&&yl==0&&yd==0)
		final="none";
	else if (yi==1 && yl==1 && yd==1)
		final="idl";
	else if (yi==1 && yl==1)
		final="il";
	else if (yi==1 && yd==1)
		final="id";
	else if (yl==1 && yd==1)
		final="dl";
	else if(yi==1) final="i";
	else if (yd==1) final="d";
	else if (yl==1) final="l";
	///////////
	
	int opernum=3*threadnum*iternum;
	strcat(type, "list-");
	strcat(type, final);
	
	if(syncflag==0) 
		strcat(type, "-none");
	else if(syncflag=='m')
		strcat(type, "-m");
	else if (syncflag=='s')
		strcat(type, "-s");
	
	signal(SIGSEGV, signal_handler_fun);
	randomstuff=malloc(sizeof(SortedListElement_t) * threadnum * iternum);
	
	if (randomstuff==NULL){
		fprintf(stderr,"error when mallocing randomstuff");
		exit(2);
	}
	
	srand(time(0));
	for (int i = 0; i < threadnum*iternum ; i++) {
    char *key = randomkey();
    SortedListElement_t element = {NULL, NULL, key};
    randomstuff[i] = element;
  }


	struct timespec start, end;
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);

  
	pthread_t *threads = malloc(sizeof(pthread_t) * threadnum);
	int *threadinds = malloc(sizeof(int) * threadnum);
	if (threads==NULL){
		fprintf(stderr, "thread malloc problem \n");
		exit(2);
	}
	
	for (int i = 0; i < threadnum; i++) {
		threadinds[i] = i;
		if(pthread_create(&threads[i], NULL, &threadfunc, &threadinds[i])){
			fprintf(stderr, "thread create error \n");
			exit(2);
		}
	}
  
  
	for (int i = 0; i < threadnum; i++) {
		if( pthread_join(threads[i], NULL)){
			fprintf(stderr, "join failure \n");
			exit(2);
		}
	}
	
	
	int length = SortedList_length(&list);
	if (length != 0){
		fprintf(stderr, "the final length is not 0 \n");
		exit(2);
	}	
  

	
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);
	long long diff = (end.tv_sec - start.tv_sec) * 1000000000;
	diff = diff + end.tv_nsec - start.tv_nsec;
	long long avg = diff / opernum;
	
	
	
	
	printf("%s,%d,%d,1,%d,%lld,%lld\n", type, threadnum, iternum,  opernum, diff, avg);
	return 0;
}
	
	
	
	