/* NAME: Yining Wang */
/* EMAIL: wangyining@g.ucla.edu */
/* ID: 504983099 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#include <getopt.h>
#include <errno.h>
#include <string.h>


int threads=1;
int iterations=1;
int yieldflag=0;
char syncflag=0;
//syncflag is 0 when no sync is used

pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
//pthread_mutex_init(&lock, NULL);
long long counter=0;
int spin_lock=0;

	
void addnaive(long long *pointer, long long value) {
	long long sum = *pointer + value;
	if (yieldflag)
		sched_yield();
	*pointer = sum;
    }
	
void add(int val){
	
	long long  tmp, tmpsum;
	
	
	
	if(syncflag==0){
		for(int i=0;i<iterations;i++)
			addnaive(&counter,val);	
	}
	//m mutex
	else if (syncflag=='m'){
		for(int i=0;i<iterations;i++){
			pthread_mutex_lock(&lock);
            addnaive(&counter, val);
            pthread_mutex_unlock(&lock);
		}
	}
	//s spin lock
	
	else if (syncflag=='s'){
		for(int i=0;i<iterations;i++){
			while (__sync_lock_test_and_set(&spin_lock, 1))
				continue;
            addnaive(&counter, val);
            __sync_lock_release(&spin_lock);
		}
	}
	//c compare and swap
	
	else if (syncflag=='c'){
		for(int i=0;i<iterations;i++){
			do{
				tmp = counter;
				tmpsum = tmp + val;
				if (yieldflag)
					sched_yield();
			}while(__sync_val_compare_and_swap(&counter, tmp, tmpsum) != tmp);
			
		}
	}
	
}

void* threadfunc() {
    add(1);
    add(-1);
    return NULL;
}
	


struct option options[] = {
  {"threads", 1, 0, 1}, //THREADS
  {"iterations", 1, 0, 2}, //ITERATIONS
  {"yield", 0, 0, 3}, //YIELD
  {"sync", 1, 0, 4},//SYNC
  {0, 0, 0, 0}
};






int main(int argc, char** argv){
	
	char *type = malloc(sizeof(char) * 20);
	
	
	while(1){
		int opt = getopt_long(argc, argv, "", options, NULL);
		if (opt == -1)
			break;
		switch(opt) {
			case 1: //threads
			threads=atoi(optarg);
			if(threads<0 || threads>100){
				fprintf(stderr, "thread number is wrong \n");
				exit(1);
			}
			break;
			
			case 2: //iterations
			iterations=atoi(optarg);
			if(iterations<0){
				fprintf(stderr, "iteration number is wrong \n");
				exit(1);
			}
			break;
			
			case 3: //yield
			yieldflag=1;
			break;
			
			case 4: //sync
			syncflag=optarg[0];
			if(syncflag!='m' &&syncflag!='s' &&syncflag!='c'){
				fprintf(stderr, "the sync flag is not recocgnized");
				exit(1);
			}
			break;
	
			default:
			fprintf(stderr,"the argument is not recognized");
			exit(1);
		}
	
	
	}
	
	int countoperations = threads * iterations * 2;
	strcat(type, "add");
	if (yieldflag)
		strcat(type, "-yield");
	if(syncflag==0)
    strcat(type, "-none");
	else if (syncflag=='m')
		strcat(type, "-m"); 
	else if (syncflag=='s')
		strcat(type, "-s");
	else if (syncflag=='c')
		strcat(type, "-c");
	
	struct timespec start, end;
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);
	pthread_t *ourthreads = malloc(sizeof(pthread_t) * threads);
	if(ourthreads==NULL){
		fprintf(stderr, "error when mallocing threads \n");
		exit(2);
	}
	
	for (int i = 0; i < threads; i++) {
        if (pthread_create(&ourthreads[i], NULL, &threadfunc, NULL)) {
            fprintf(stderr, "error in creating the threads \n");
            exit(2);
        }
		
    }
	
	for (int i = 0; i < threads; i++) {
		if(pthread_join(ourthreads[i], NULL)){
			fprintf(stderr,"error in joining threads \n");
			exit(2);
		}
	}
	
	clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);
	long long diff = (end.tv_sec - start.tv_sec) * 1000000000;
	diff = diff + end.tv_nsec - start.tv_nsec;
	long long avg = diff / countoperations;
	printf("%s,%d,%d,%d,%lld,%lld,%lld\n", type, threads, iterations, countoperations, diff, avg, counter);

  return 0;
	
	
  
	
	
	
}