./lab4b --period=2 --scale=C --log=LOGFILE <<EOF
SCALE=F
STOP
OFF
EOF
ret=$?
if [ $ret -eq 0 ]
then
	echo "passed"
else
	echo "failed"
fi
